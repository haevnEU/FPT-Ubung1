package core.interfaces;

/**
 * This interface is used as a skeleton for every core.view
 * Future usage could be implantation of localization
 */
public interface IView { }
