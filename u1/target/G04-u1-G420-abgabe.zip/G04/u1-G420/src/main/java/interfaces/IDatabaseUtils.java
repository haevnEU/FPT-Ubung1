package interfaces;

public interface IDatabaseUtils extends ISerializableStrategy {}
