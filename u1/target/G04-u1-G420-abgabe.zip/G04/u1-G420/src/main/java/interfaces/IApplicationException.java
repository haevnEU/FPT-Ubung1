package interfaces;

public interface IApplicationException {}
