package core;

/**
 * This enum provides
 *
 * Written by Nils Milewsi (nimile)
 */
public enum SelectedSongList {
	PlayList, Library
}
