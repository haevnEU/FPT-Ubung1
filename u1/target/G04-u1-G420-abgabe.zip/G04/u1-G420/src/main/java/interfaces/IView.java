package interfaces;

public interface IView {

	/**
	 * Should reset the object
	 */
	void destroy();
}
