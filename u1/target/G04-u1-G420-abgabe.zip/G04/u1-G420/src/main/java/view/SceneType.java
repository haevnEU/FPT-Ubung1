package view;

/**
 * Provides human readability
 */
public enum SceneType {
	MainView, DeleteView, DetailView, SaveView, LoadView
}
