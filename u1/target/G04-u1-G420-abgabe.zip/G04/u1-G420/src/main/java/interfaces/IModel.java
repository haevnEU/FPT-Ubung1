package interfaces;

public interface IModel {}
