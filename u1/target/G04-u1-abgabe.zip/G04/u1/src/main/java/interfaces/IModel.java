package interfaces;

/**
 * This interface is a blueprint for models
 */
public interface IModel {
}
